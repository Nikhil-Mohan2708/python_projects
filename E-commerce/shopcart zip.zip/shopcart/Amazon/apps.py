from django.apps import AppConfig


class AmazonConfig(AppConfig):
    name = 'Amazon'
