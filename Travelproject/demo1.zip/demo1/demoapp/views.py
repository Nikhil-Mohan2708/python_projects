# from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def demo (request):
     return render(request,"index.html")

# def operation (request):
#     x=float(request.GET['num1'])
#     y=float(request.GET['num2'])
#     result_add=x+y
#     result_sub = x - y
#     result_multi = x * y
#     result_div = x / y
#     return render(request,"result.html",{'res':result_add,'res_sub': result_sub,'res_multi':result_multi,'res_div':result_div})

